package edu.ucopensar.codigo;

import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ArrayList<Producto> productos = new ArrayList<>();

        productos.add(new Producto("P001", "Laptop", "Tecnologia", 2500, 5));
        productos.add(new Producto("P002", "Mouse", "Tecnologia", 80, 15));
        productos.add(new Producto("P003", "Cuaderno", "Papeleria", 10, 100));
        productos.add(new Producto("P004", "Escritorio", "Muebles", 400, 8));
        productos.add(new Producto("P005", "Nevera", "Electrodomesticos", 1800, 3));


        System.out.println("Punto 1");

        int cantidadProductos = productos.size();

        double sumaPrecios = 0;
        int stockMenor10 = 0;

        Producto masCostoso = productos.get(0);
        Producto masBarato = productos.get(0);

        for (int i = 0; i < productos.size(); i++) {

            Producto p = productos.get(i);

            sumaPrecios += p.precio;

            if (p.precio > masCostoso.precio) {
                masCostoso = p;
            }

            if (p.precio < masBarato.precio) {
                masBarato = p;
            }

            if (p.stock < 10) {
                stockMenor10++;
            }
        }

        double promedio = sumaPrecios / cantidadProductos;

        System.out.println("Cantidad total productos: " + cantidadProductos);
        System.out.println("Promedio precios: " + promedio);
        System.out.println("Producto mas costoso: " + masCostoso.nombre + " $" + masCostoso.precio);
        System.out.println("Producto mas barato: " + masBarato.nombre + " $" + masBarato.precio);
        System.out.println("Productos con stock menor a 10: " + stockMenor10);

        System.out.println("\nPunto 2");

        ArrayList<Producto> productosTecnologia = new ArrayList<>();
        ArrayList<Producto> productosEconomicos = new ArrayList<>();

        for (int i = 0; i < productos.size(); i++) {

            Producto p = productos.get(i);

            if (p.categoria.equalsIgnoreCase("Tecnologia")) {
                productosTecnologia.add(p);
            }

            if (p.precio < 200) {
                productosEconomicos.add(p);
            }
        }

        System.out.println("\nPRODUCTOS TECNOLOGIA");

        for (int i = 0; i < productosTecnologia.size(); i++) {
            System.out.println(productosTecnologia.get(i));
        }

        System.out.println("\nPRODUCTOS ECONOMICOS");

        for (int i = 0; i < productosEconomicos.size(); i++) {
            System.out.println(productosEconomicos.get(i));
        }

        double valorTecnologia = 0;
        double valorEconomicos = 0;

        for (int i = 0; i < productosTecnologia.size(); i++) {
            valorTecnologia += productosTecnologia.get(i).precio
                    * productosTecnologia.get(i).stock;
        }

        for (int i = 0; i < productosEconomicos.size(); i++) {
            valorEconomicos += productosEconomicos.get(i).precio
                    * productosEconomicos.get(i).stock;
        }

        System.out.println("\nValor inventario tecnologia: $" + valorTecnologia);
        System.out.println("Valor inventario economicos: $" + valorEconomicos);


        int opcion;

        do {

            System.out.println("\nMenu:");
            System.out.println("1. Buscar producto por codigo");
            System.out.println("2. Actualizar precio");
            System.out.println("3. Actualizar stock");
            System.out.println("4. Eliminar producto");
            System.out.println("5. Mostrar inventario");
            System.out.println("6. Mostrar productos por categoria");
            System.out.println("7. Salir");

            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {

                case 1:

                    System.out.print("Ingrese codigo: ");
                    String codigoBuscar = sc.nextLine();

                    boolean encontrado = false;

                    for (int i = 0; i < productos.size(); i++) {

                        if (productos.get(i).codigo.equalsIgnoreCase(codigoBuscar)) {
                            System.out.println(productos.get(i));
                            encontrado = true;
                            break;
                        }
                    }

                    if (!encontrado) {
                        System.out.println("Producto no encontrado");
                    }

                    break;

                case 2:

                    System.out.print("Ingrese codigo: ");
                    String codigoPrecio = sc.nextLine();

                    System.out.print("Nuevo precio: ");
                    double nuevoPrecio = sc.nextDouble();

                    for (int i = 0; i < productos.size(); i++) {

                        if (productos.get(i).codigo.equalsIgnoreCase(codigoPrecio)) {

                            productos.get(i).precio = nuevoPrecio;
                            System.out.println("Precio actualizado");
                        }
                    }

                    break;

                case 3:

                    System.out.print("Ingrese codigo: ");
                    String codigoStock = sc.nextLine();

                    System.out.print("Nuevo stock: ");
                    int nuevoStock = sc.nextInt();

                    for (int i = 0; i < productos.size(); i++) {

                        if (productos.get(i).codigo.equalsIgnoreCase(codigoStock)) {

                            productos.get(i).stock = nuevoStock;
                            System.out.println("Stock actualizado");
                        }
                    }

                    break;

                case 4:

                    System.out.print("Ingrese codigo: ");
                    String codigoEliminar = sc.nextLine();

                    for (int i = 0; i < productos.size(); i++) {

                        if (productos.get(i).codigo.equalsIgnoreCase(codigoEliminar)) {

                            productos.remove(i);
                            System.out.println("Producto eliminado");
                            break;
                        }
                    }

                    break;

                case 5:

                    System.out.println("\nINVENTARIO");

                    for (int i = 0; i < productos.size(); i++) {

                        System.out.println(productos.get(i));
                    }

                    break;

                case 6:

                    System.out.print("Ingrese categoria: ");
                    String categoria = sc.nextLine();

                    System.out.println("\nPRODUCTOS DE LA CATEGORIA");

                    for (int i = 0; i < productos.size(); i++) {

                        if (productos.get(i).categoria.equalsIgnoreCase(categoria)) {

                            System.out.println(productos.get(i));
                        }
                    }

                    break;

                case 7:

                    System.out.println("Programa finalizado");
                    break;

                default:

                    System.out.println("Opcion invalida");
            }

        } while (opcion != 7);

    }
}