package edu.ucopensar.codigo;

public class Producto {

    String codigo;
    String nombre;
    String categoria;
    double precio;
    int stock;

    public Producto(String codigo, String nombre, String categoria, double precio, int stock) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
    }

    @Override
    public String toString() {
        return codigo + " | " + nombre + " | " + categoria
                + " | $" + precio + " | Stock: " + stock;
    }
}